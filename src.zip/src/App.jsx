import "./App.css";
import Router from './routes/Router';
import Routermain from './routes/Routermain';
import Sidebar from "./components/Sidebar/Sidebar";
import TopNav from "./components/TopNav/TopNav";


const App = () => {

  if (!(window.location.pathname === '/signin')) {
    return (
      <div className="layout">
        <Sidebar />
        <div className="main__layout">
          <TopNav />
          <div className="content">
            <Router />
          </div>
        </div>
      </div>
    )
  }
  return (
    <div>
      <Routermain />
    </div>
  )

}

export default App;
