import React, { useState, useContext } from 'react';
import { signInWithGooglePopup, createUserDocFromAuth, signinUserWithEmailAndPassword } from '../utils/firebase/firebase';
import "../styles/signin.css";
import { Link } from 'react-router-dom';
import { UserContext } from "../components/context/userContext";

const defaultFormFields = {
    email: '',
    password: ''
}

const Signin = () => {
    const userG = async () => {
        const { user } = await signInWithGooglePopup();
        await createUserDocFromAuth(user);
        setCurrentUser(user);
        if (currentUser) {
            window.location.pathname = '/dashboard';
        }
    }

    const [formFields, setFormFields] = useState(defaultFormFields);

    const { email, password } = formFields;

    const { setCurrentUser, currentUser } = useContext(UserContext);

    // const [userexists, setuser] = useState(false);

    const signinhandler = async (event) => {
        event.preventDefault();
        try {
            const { user } = await signinUserWithEmailAndPassword(email, password);
            // setuser(true);
            setCurrentUser(user);
            if (currentUser) {
                window.location.pathname = '/dashboard';
            }
            // currentUser ? (window.location.pathname = '/dashboard') : (window.location.pathname = '/signin') 
        } catch (error) {
            alert('wrong username or password', error);
        }
    }

    // const navigate = () => {
    //     if (currentUser) {
    //         window.location.pathname = '/dashboard';
    //     }
    // }
    const inputhandler = (event) => {
        const { name, value } = event.target;
        setFormFields({ ...formFields, [name]: value })
    }

    return (
        <div className='wrapper'>
            <div className='signin'>
                <h2>Get's started.</h2>
                <div className='new__acc'>
                    <p>Don't have an account?  </p>
                    <Link to={"/signup"}> Signup </Link>
                </div>
                <div className='options__buttons'>
                    <button onClick={userG}>
                        <i class="ri-google-fill"></i>
                        Signin with google
                    </button>
                    <button>
                        <i class="ri-facebook-fill"></i>
                        Signin with Facebook
                    </button>
                </div>
                <div>
                    <form className='submit__info' onSubmit={signinhandler} >
                        <div className='signin__form'>
                            <label>Email</label>
                            <input type="email" onChange={inputhandler} name="email" value={email} required />
                            <label>Password</label>
                            <input type="password" onChange={inputhandler} name="password" value={password} required />
                        </div>
                        <button type='submit' >Submit</button>
                    </form>
                </div>
            </div>
        </div>

    )
}

export default Signin