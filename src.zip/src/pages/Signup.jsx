import React, {useState} from 'react';
import '../styles/signup.css';
import { Link } from 'react-router-dom';
import {
  createAuthUserWithEmailAndPassword,
  createUserDocFromAuth
} from '../utils/firebase/firebase'

const defaultFormFields = {
  displayName: '',
  lastName: '',
  email: '',
  password: ''
}

const Signup = () => {
  const [formFields, setFormFields] = useState(defaultFormFields);
  const { displayName, lastName, email, password } = formFields;
  const [userexists , setuser] = useState(false);

  const signuphandler = async (event) => {
    event.preventDefault();
    try {

      const {user} = await createAuthUserWithEmailAndPassword(email, password);

      await createUserDocFromAuth(user, { displayName, password});
      setuser(true);
    } catch (error) {
      if (error.code === 'auth/email-already-in-use') {
        alert('user already exists', error);
      }
      console.log('error', error);
    }
  }

  const navigate = () => {
    if (userexists) {
      window.location.pathname = '/dashboard';
    }
  }

  const inputhandler = (event) => {
    const { name, value } = event.target;
    setFormFields({ ...formFields, [name]: value })
  }

  return (
    <div className='wrapper'>
      <div className='signup'>
        <h2>Get's started</h2>
        <div className='signup__formm'>
          <div className='new__acc'>
            <p>Already have an account?  </p>
            <Link to={"/signin"}> Signin </Link>
          </div>
          <form className='submit__infoo' onSubmit={signuphandler}>
            <div className='signup__form'>
              <label>First name</label>
              <input type="text" onChange={inputhandler} name="displayName" value={displayName} />
              <label>Last name</label>
              <input type="text" onChange={inputhandler} name="lastName" value={lastName} />
              <label>Email</label>
              <input type="email" onChange={inputhandler} name="email" value={email} />
              <label>Password</label>
              <input type='password' onChange={inputhandler} name="password" value={password} />
            </div>

            <button type='submit' onClick={navigate}>Submit</button>

          </form>
        </div>
      </div>
    </div>

  )
}

export default Signup