import React from "react";
import ReactDOM from "react-dom";
import "remixicon/fonts/remixicon.css";
import "react-circular-progressbar/dist/styles.css";
import App from "./App";
import { BrowserRouter } from "react-router-dom";
import { UserProvider } from './components/context/userContext';
import { CarProvider } from './components/context/carContext';
import { ListProvider } from './components/context/wishListContext';

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <UserProvider>
        <CarProvider>
          <ListProvider>
            <App />
          </ListProvider>
        </CarProvider>
      </UserProvider>
    </BrowserRouter>
  </React.StrictMode>
);
