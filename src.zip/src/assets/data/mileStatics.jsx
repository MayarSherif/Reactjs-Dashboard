const mileStatics = [
  {
    name: "Sat",
    value: 6000,
  },
  {
    name: "Sun",
    value: 5000,
  },
  {
    name: "Mon",
    value: 7000,
  },
  {
    name: "Tue",
    value: 5780,
  },
  {
    name: "Wed",
    value: 4890,
  },
  {
    name: "Thu",
    value: 6390,
  },
  {
    name: "Fri",
    value: 5490,
  },
];

export default mileStatics;
