const trackingData = [
    {
      name: "Sat",
      value: 10,
       
    },
    {
      name: "Sun",
      value: 8,
      
    },
    {
      name: "Mon",
      value: 18,
      
    },
    {
      name: "Tue",
      value: 23,
      
    },
    {
      name: "Wed",
      value: 21,
      
    },
    {
      name: "Thu",
      value: 14,
      
    },
    {
      name: "Fri",
      value: 33,
    },
  ];
  
  export default trackingData;
  