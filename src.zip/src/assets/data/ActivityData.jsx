const ActivityData = [
    {
      month: "12/9",
      km: 40,
    },
    {
      month: "12/9",
      km: 45,
    },
    {
      month: "12/9",
      km: 55,
    },
    {
      month: "12/9",
      km: 65,
    },
    {
      month: "12/9",
      km: 60,
    },
    {
      month: "12/9",
      km: 50,
    },
    {
      month: "12/9",
      km: 48,
    },
    {
      month: "12/9",
      km: 60,
    },
    {
      month: "12/9",
      km: 70,
    },
    {
      month: "12/9",
      km: 75,
    },
    {
      month: "12/9",
      km: 80,
    },
    {
      month: "12/9",
      km: 85,
    },
  ];
  
  export default ActivityData;
  